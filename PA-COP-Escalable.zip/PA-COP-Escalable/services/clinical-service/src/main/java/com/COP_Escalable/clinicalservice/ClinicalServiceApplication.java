package com.COP_Escalable.clinicalservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ClinicalServiceApplication {
	public static void main(String[] args) {
		SpringApplication.run(ClinicalServiceApplication.class, args);
	}
}

